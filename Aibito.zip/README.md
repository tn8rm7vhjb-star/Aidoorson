
# iPhone-webapp voor AI Trading Bot

Dit is een webinterface rond de bestaande paper-trading bot.

## Belangrijk
- Dit is nog steeds PAPER TRADING / BACKTESTING.
- Er wordt geen echte order naar een exchange gestuurd.
- De webapp moet op een server/cloud-omgeving draaien om hem vanaf een iPhone te openen.

## Lokaal starten
Python 3.11+:
pip install -r requirements.txt
python app.py

Open daarna in een browser:
http://localhost:8080

## Online maken
Zet deze map op een Python-hostingdienst die Flask ondersteunt. Startcommando:
python app.py

De server moet poort 8080 of de door de hostingdienst ingestelde PORT gebruiken.
