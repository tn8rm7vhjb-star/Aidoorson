
from flask import Flask, render_template, jsonify
import subprocess, sys, os, json, csv

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.post("/run")
def run_bot():
    try:
        result = subprocess.run(
            [sys.executable, "bot.py"],
            capture_output=True, text=True, timeout=180
        )
        summary = {}
        for line in result.stdout.splitlines():
            if "Eindkapitaal:" in line:
                summary["ending"] = line.split(":",1)[1].strip()
            elif "Winst/verlies:" in line:
                summary["pnl"] = line.split(":",1)[1].strip()
            elif "Totaal rendement:" in line:
                summary["return"] = line.split(":",1)[1].strip()
            elif "Max drawdown:" in line:
                summary["drawdown"] = line.split(":",1)[1].strip()
            elif "Afgesloten trades:" in line:
                summary["trades"] = line.split(":",1)[1].strip()
        return jsonify(ok=result.returncode == 0, summary=summary, log=result.stdout[-8000:], error=result.stderr[-4000:])
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
