"""
AI Trading Bot v1 — PAPER TRADING ONLY
Markets: QNT, ARB, HYPE, XRP, SOL, BTC
Starting capital: €750

This is an educational baseline, not financial advice.
The "AI" component is a probability model (RandomForest) trained only on
historical features. It does NOT guarantee profitable predictions.

Data source: Binance public klines for symbols available there.
HYPE may not be available on Binance; unsupported symbols are skipped with
a warning. For HYPE, replace DATA_SOURCE_SYMBOLS["HYPE"] with a symbol from
your chosen exchange/data provider.

Install:
    pip install -r requirements.txt

Run:
    python bot.py

The program:
1. Downloads historical OHLCV data.
2. Creates technical features.
3. Trains a RandomForest probability model using a time-ordered split.
4. Runs a simple walk-forward-style backtest on the final test period.
5. Simulates portfolio trades with €750 starting capital.
6. Prints/saves a P&L report.
"""

import time
from dataclasses import dataclass
from typing import Dict, List

import ccxt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score


START_CAPITAL = 750.0
RISK_PER_TRADE = 0.01          # 1% of current equity
MAX_TOTAL_EXPOSURE = 0.80      # max 80% of equity invested
FEE_RATE = 0.001               # 0.10% per side
STOP_LOSS = 0.03               # 3%
TAKE_PROFIT = 0.06             # 6%
BUY_THRESHOLD = 0.58
SELL_THRESHOLD = 0.45
TIMEFRAME = "1h"
LIMIT = 1500

# Public Binance spot symbols. Verify availability before live use.
DATA_SOURCE_SYMBOLS = {
    "BTC": "BTC/USDT",
    "SOL": "SOL/USDT",
    "XRP": "XRP/USDT",
    "ARB": "ARB/USDT",
    "QNT": "QNT/USDT",
    "HYPE": "HYPE/USDT",
}


@dataclass
class Position:
    symbol: str
    qty: float
    entry: float
    invested: float


def fetch_ohlcv(exchange, symbol: str, limit: int = LIMIT) -> pd.DataFrame:
    rows = exchange.fetch_ohlcv(symbol, timeframe=TIMEFRAME, limit=limit)
    if not rows:
        raise ValueError("No OHLCV data returned")
    df = pd.DataFrame(
        rows, columns=["timestamp", "open", "high", "low", "close", "volume"]
    )
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()

    d["ret_1"] = d["close"].pct_change()
    d["ret_6"] = d["close"].pct_change(6)
    d["ret_24"] = d["close"].pct_change(24)

    d["sma_12"] = d["close"].rolling(12).mean()
    d["sma_24"] = d["close"].rolling(24).mean()
    d["sma_72"] = d["close"].rolling(72).mean()

    d["ema_12"] = d["close"].ewm(span=12, adjust=False).mean()
    d["ema_26"] = d["close"].ewm(span=26, adjust=False).mean()
    d["macd"] = d["ema_12"] - d["ema_26"]
    d["macd_signal"] = d["macd"].ewm(span=9, adjust=False).mean()

    delta = d["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    d["rsi"] = 100 - (100 / (1 + rs))

    tr = pd.concat(
        [
            d["high"] - d["low"],
            (d["high"] - d["close"].shift()).abs(),
            (d["low"] - d["close"].shift()).abs(),
        ],
        axis=1,
    ).max(axis=1)
    d["atr_pct"] = tr.rolling(14).mean() / d["close"]

    d["vol_z"] = (
        (d["volume"] - d["volume"].rolling(48).mean())
        / d["volume"].rolling(48).std()
    )

    # Prediction target: whether the next 6 hourly closes are positive.
    d["target"] = (d["close"].shift(-6) > d["close"]).astype(int)

    return d.replace([np.inf, -np.inf], np.nan).dropna()


FEATURES = [
    "ret_1", "ret_6", "ret_24",
    "sma_12", "sma_24", "sma_72",
    "macd", "macd_signal", "rsi", "atr_pct", "vol_z"
]


def train_and_test(df: pd.DataFrame):
    split = int(len(df) * 0.70)
    train = df.iloc[:split].copy()
    test = df.iloc[split:].copy()

    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=7,
        min_samples_leaf=8,
        random_state=42,
        class_weight="balanced_subsample",
        n_jobs=-1,
    )
    model.fit(train[FEATURES], train["target"])

    test["prob_up"] = model.predict_proba(test[FEATURES])[:, 1]

    pred = (test["prob_up"] >= 0.5).astype(int)
    accuracy = accuracy_score(test["target"], pred)
    try:
        auc = roc_auc_score(test["target"], test["prob_up"])
    except ValueError:
        auc = float("nan")

    return model, test, accuracy, auc


def backtest(test_frames: Dict[str, pd.DataFrame]):
    cash = START_CAPITAL
    positions: Dict[str, Position] = {}
    trades: List[dict] = []
    equity_curve = []

    # Align all markets by timestamp.
    all_times = sorted(set().union(*(set(df["timestamp"]) for df in test_frames.values())))

    for ts in all_times:
        prices = {}
        signals = {}

        for symbol, df in test_frames.items():
            row = df[df["timestamp"] == ts]
            if row.empty:
                continue
            r = row.iloc[0]
            prices[symbol] = float(r["close"])
            signals[symbol] = float(r["prob_up"])

        equity = cash + sum(
            pos.qty * prices[sym] for sym, pos in positions.items() if sym in prices
        )
        equity_curve.append((ts, equity))

        # First manage open positions.
        for sym in list(positions):
            if sym not in prices:
                continue
            pos = positions[sym]
            px = prices[sym]
            prob = signals[sym]

            stop = pos.entry * (1 - STOP_LOSS)
            target = pos.entry * (1 + TAKE_PROFIT)

            if px <= stop or px >= target or prob < SELL_THRESHOLD:
                gross = pos.qty * px
                fee = gross * FEE_RATE
                cash += gross - fee
                pnl = (px - pos.entry) * pos.qty - fee - pos.invested * FEE_RATE
                trades.append({
                    "timestamp": ts,
                    "symbol": sym,
                    "side": "SELL",
                    "price": px,
                    "qty": pos.qty,
                    "pnl": pnl,
                    "reason": (
                        "stop_loss" if px <= stop else
                        "take_profit" if px >= target else "ai_exit"
                    ),
                })
                del positions[sym]

        # Then consider new entries.
        equity = cash + sum(
            pos.qty * prices[sym] for sym, pos in positions.items() if sym in prices
        )
        current_exposure = sum(
            pos.qty * prices[sym] for sym, pos in positions.items() if sym in prices
        )
        exposure_room = max(0.0, equity * MAX_TOTAL_EXPOSURE - current_exposure)

        candidates = sorted(
            [(sym, prob) for sym, prob in signals.items()
             if prob >= BUY_THRESHOLD and sym not in positions],
            key=lambda x: x[1],
            reverse=True,
        )

        for sym, prob in candidates:
            if exposure_room <= 1:
                break

            # Risk budget: 1% of equity. Position size is constrained by stop distance.
            risk_budget = equity * RISK_PER_TRADE
            position_value = risk_budget / STOP_LOSS
            position_value = min(position_value, exposure_room, cash / (1 + FEE_RATE))
            if position_value < 10:
                continue

            px = prices[sym]
            qty = position_value / px
            fee = position_value * FEE_RATE
            cash -= position_value + fee
            positions[sym] = Position(sym, qty, px, position_value)
            exposure_room -= position_value

            trades.append({
                "timestamp": ts,
                "symbol": sym,
                "side": "BUY",
                "price": px,
                "qty": qty,
                "pnl": 0.0,
                "reason": f"ai_prob={prob:.3f}",
            })

    # Liquidate remaining positions at final available price.
    final_prices = {
        sym: float(df.iloc[-1]["close"]) for sym, df in test_frames.items()
    }
    for sym, pos in list(positions.items()):
        px = final_prices[sym]
        gross = pos.qty * px
        fee = gross * FEE_RATE
        cash += gross - fee
        pnl = (px - pos.entry) * pos.qty - fee - pos.invested * FEE_RATE
        trades.append({
            "timestamp": test_frames[sym].iloc[-1]["timestamp"],
            "symbol": sym,
            "side": "SELL",
            "price": px,
            "qty": pos.qty,
            "pnl": pnl,
            "reason": "end_of_test",
        })

    curve = pd.DataFrame(equity_curve, columns=["timestamp", "equity"])
    if not curve.empty:
        curve["peak"] = curve["equity"].cummax()
        curve["drawdown"] = curve["equity"] / curve["peak"] - 1
        max_drawdown = curve["drawdown"].min()
    else:
        max_drawdown = 0.0

    trades_df = pd.DataFrame(trades)
    total_return = cash / START_CAPITAL - 1

    return cash, total_return, max_drawdown, trades_df, curve


def main():
    print("=== AI Trading Bot v1 — PAPER TRADING ===")
    print(f"Startkapitaal: €{START_CAPITAL:.2f}")
    print(f"Risico per trade: {RISK_PER_TRADE:.1%}")
    print(f"Max exposure: {MAX_TOTAL_EXPOSURE:.1%}")
    print()

    exchange = ccxt.binance({"enableRateLimit": True})
    test_frames = {}
    model_stats = []

    for name, market_symbol in DATA_SOURCE_SYMBOLS.items():
        print(f"[DATA] {name}: {market_symbol}")
        try:
            df = fetch_ohlcv(exchange, market_symbol)
            df = add_features(df)

            if len(df) < 300:
                print(f"  -> overgeslagen: te weinig bruikbare candles ({len(df)})")
                continue

            _, test, accuracy, auc = train_and_test(df)
            test_frames[name] = test

            model_stats.append({
                "symbol": name,
                "test_rows": len(test),
                "accuracy": accuracy,
                "roc_auc": auc,
            })
            print(f"  -> test accuracy={accuracy:.3f}, ROC-AUC={auc:.3f}")

        except Exception as exc:
            print(f"  -> NIET BESCHIKBAAR / fout: {exc}")

    if not test_frames:
        raise RuntimeError(
            "Geen markten konden worden geladen. Controleer exchange-symbolen "
            "en internetverbinding."
        )

    final_cash, total_return, max_dd, trades, curve = backtest(test_frames)

    stats_df = pd.DataFrame(model_stats)
    stats_df.to_csv("model_stats.csv", index=False)
    trades.to_csv("trades.csv", index=False)
    curve.to_csv("equity_curve.csv", index=False)

    print("\n=== RESULTAAT ===")
    print(f"Eindkapitaal:     €{final_cash:,.2f}")
    print(f"Winst/verlies:    €{final_cash - START_CAPITAL:,.2f}")
    print(f"Totaal rendement: {total_return:.2%}")
    print(f"Max drawdown:     {max_dd:.2%}")
    if not trades.empty:
        sells = trades[trades["side"] == "SELL"]
        print(f"Afgesloten trades:{len(sells)}")
        print(f"Trade-P&L:        €{sells['pnl'].sum():,.2f}")

    print("\nBestanden opgeslagen:")
    print("  model_stats.csv")
    print("  trades.csv")
    print("  equity_curve.csv")
    print("\nLET OP: dit is een backtest/paper-trading prototype. "
          "Resultaten uit het verleden voorspellen geen toekomstige winst.")


if __name__ == "__main__":
    main()
